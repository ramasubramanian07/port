<?php
include 'db.php';
if(isset($_POST['edit']))
{
	$search=$_POST['rollno'];
	
		$sname=$_POST['sname'];
		$s_dob=$_POST['s_dob'];
		$gender=$_POST['gender'];
		$phno=$_POST['phno'];
		$wtsapp=$_POST['wtsapp'];
		$email=$_POST['email'];
		$schltype=$_POST['schltype'];
		$schlstu=$_POST['schlstu'];
		$emis=$_POST['emis'];
		$religion=$_POST['religion'];
		$community=$_POST['community'];
		$caste=$_POST['caste'];
		$nation=$_POST['nation'];
		$mother_tongue=$_POST['mother_tongue'];
		$aadharno=$_POST['aadharno'];
		$first_graduation=$_POST['first_graduation'];
		$query="update personal set sname='$sname',s_dob='$s_dob',gender='$gender',phno='$phno',wtsapp='$wtsapp',email='$email',schltype='$schltype',schlstu='$schlstu',emis='$emis',religion='$religion',community='$community',caste='$caste',nation='$nation',mother_tongue='$mother_tongue',aadharno='$aadharno',first_graduation='$first_graduation'";
		$up_run=mysqli_query($conn,$query);
		if($up_run)
		{
			echo"<script>alert('success');</script>";
		}
		else
		{
			echo"<script>alert('not success');</script>";
		}

	
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Admin</title>
</head>

<body>
<form method="POST">
<input type="text" placeholder="search" name="search">
<button name="submit">search</button>
</form>
		<?php
		if(isset($_POST['submit']))
{
	$search=$_POST['search'];
	//$sql="select * from personal join academic_details on personal.rollno=academic_details.rollno join parent_details on personal.rollno=parent_details.rollno where rollno='$search'";
	//$sql="select * from personal p inner join academic_details a on p.rollno=a.rollno join  parent_details pm on p.rollno=pm.rollno where rollno='$search'";
    $sql="select *from personal where rollno='$search'";
	$result=mysqli_query($conn,$sql);
	while($row=mysqli_fetch_assoc($result))
		{
            echo' 
    <section id="Applicant_Personal">
        <h1 style="margin-left: 15px;">Student Details</h1>
		<form  action="" method="POST">
        <div class="personal">
            <h2>Personal Details</h2>
	   
			<div class="personal_row_1">
                    <div class="frm-template">
                        <label for="sname">Student Name<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="sname" name="sname" value='.$row["sname"].' placeholder="Enter StudentName" required />
                    </div>
                    <div class="frm-template">
                        <label for="s_dof">Date of Birth<span class="mandatory">*</span>
                        </label>
                        <input type="date" name="s_dob" value='.$row["s_dob"].' id="s_dof" placeholder="Enter Date of Birth" required />
                    </div>
                    <div class="frm-template">
                        <label for="Gender">Gender<span class="mandatory">*</span>
                        </label>
                        <select name="gender" id="Gender" required >
							<option value="">'.$row["gender"].'</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>

                    </div>

                </div>

                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="phone">Phone Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="phone" maxlength="10" name="phno" value='.$row["phno"].' placeholder="Enter PhoneNumber" required />
                    </div>

                    <div class="frm-template">

                        <label for="wtsapp">Whatsapp Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="wtsapp" maxlength="10" minlength="10" name="wtsapp" value='.$row["wtsapp"].' placeholder="Enter WhatsappNumber" required />
                    </div>
                    <div class="frm-template">
                        <label for="state">Mail Id<span class="mandatory">*</span>
                        </label>
                        <input type="email" id="mailid" name="email" value='.$row["email"].' placeholder="Enter Mail-Id" required />
                    </div>

                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="schltype">School Type<span class="mandatory">*</span>
                        </label>
                        <select name="schltype" id="schltype">
                            <option value="none" selected>'.$row["schltype"].'</option>
                            <option value="Govt">Goverment</option>
                            <option value="Govt.Aided">Govt.Aided</option>
                            <option value="Private">Private</option>
                            <option value="CBSE">CBSE</option>
                        </select>
                    </div>

                    <div class="frm-template">
                        <label for="sclname">School Name<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="sclname" name="schlstu" value='.$row["schlstu"].' placeholder="School Name" required />
                    </div>
                    <div class="frm-template">
                        <label for="emis">Emis Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="emis" id="emis" value='.$row["emis"].' placeholder="Enter EmisNumber" required />
                    </div>
                </div>


                <div class="personal_row_1">


                    <div class="frm-template">
                        <label for="nation">Religion<span class="mandatory">*</span>
                        </label>
                        <select name="religion">
                            <option value="" selected>'.$row["religion"].'</option>
                            <option value="hindu">Hindu</option>
                            <option value="chirstian">Chirstian</option>
                            <option value="muslim">Muslim</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="nation">Community<span class="mandatory">*</span>
                        </label>
                        <select name="community">
                            <option value="" selected>'.$row["community"].'</option>
                            <option value="oc">Oc</option>
                            <option value="bc">BC</option>
                            <option value="dnc">DNC</option>
                            <option value="sc">SC</option>
                            <option value="st">ST</option>
                        </select>
                    </div>
                    <div class="frm-template">

                        <label for="nation">Caste<span class="mandatory">*</span>
                        </label>
                        <select name="caste">
                            <option value="" selected>'.$row["caste"].'</option>
                            <option value="caste-1">caste-1</option>
                            <option value="caste-2">caste-2</option>
                        </select>
                    </div>
                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="nation">Nationality
                        </label>
                        <select name="nation">
                            <option value="" selected>'.$row["nation"].'</option>
                            <option value="indian">Indian</option>
                            <option value="others">Others</option>
                        </select>
                    </div>

                    <div class="frm-template">

                        <label for="nation">Mother Tongue
                        </label>
                        <select name="mother_tongue">
                            <option value="" selected>'.$row["mother_tongue"].'</option>
                            <option value="tamil">Tamil</option>
                            <option value="malayalam">Malayalam</option>
                            <option value="telugu">Telugu</option>
                            <option value="kannada">Kannda</option>
                            <option value="hindi">Hindi</option>
                            <option value="others">Others</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="aadharno">Aadhar Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="aadharno" value='.$row["aadharno"].' maxlength="12" id="aadharno" placeholder="Enter AadharNumber" required />
                    </div>
                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="first_graduation">First Graduation<span class="mandatory">*</span>
                        </label>
                        <select name="first_graduation" required>
                            <option value="" selected>'.$row["first_graduation"].'</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                    </div>
                </div>
				<div></div>
				<div></div>
	
                <a href="#Applicant_Academic"><input type="button" class="btn " value="Next"
                        style="position: relative;right:-80% !important;"></a>';
		}
}
?>


        </div>
		</section>


    <section id="Applicant_Academic">
        <div class="Academic_Details">
            <h2>Academic Details</h2>


                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="rollno">Roll Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="rollno" name="rollno" placeholder="Enter RollNumber" required />
                    </div>
                    <div class="frm-template">
                        <label for="regno">Register Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="regno" id="regno" placeholder="Enter RegisterNumber" required />
                    </div>
                   
                    <div class="frm-template">
                        <label for="a_year">Academic Year<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="a_year" name="a_year"placeholder="Enter Academic Year(Ex:2021-2022)" required />

                    </div>
                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="admno">Admission Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="admno" name="a_no" placeholder="Enter AdmissionNumber" required />
                    </div>
                    <div class="frm-template">
                        <label for="admdate">Admission Date
                        </label>
                        <input type="date" name="admdate" id="admdate" placeholder="Enter AdmissionDate" />
                    </div>
                    <div class="frm-template">
                        <label for="admdate">Admission Year<span class="mandatory">*</span>
                        </label>
                        <input type="date" name="admyear" id="admyear" placeholder="Enter AdmissionYear..." />
                    </div>
                    
                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="C_type">CourseType<span class="mandatory">*</span>
                        </label>
                        <!--<input type="Text" id="clsofleaving" name="clsofleaving"placeholder="Class of Leaving.."/>
                        --><select name="c_type" id="C_type">
                            <option value="" selected>Select</option>
                            <option value="ug">UG</option>
                            <option value="pg">PG</option>
                        </select>
                    </div>
					<div class="frm-template">
                        <label for="c_name">Course Name<span class="mandatory">*</span>
                        </label>
                        <!--<input type="Text" id="clsofleaving" name="clsofleaving"placeholder="Class of Leaving.."/>
                        --><select name="c_name" id="c_name">
                            <option value="" selected>Select</option>
                            <option value="bcom">B.come</option>
                            <option value="bca">Bca</option>
                            <option value="bcs">B.sc com.sci</option>
                        </select>
                    </div>
					<div class="frm-template">
                        <label for="clsyear">Year<span class="mandatory">*</span>
                        </label>
                        <select name="year" id="clsyear">
                            <option value="" selected>Select</option>
                            <option value="year_1">I Year</option>
                            <option value="year_2">II Year</option>
                            <option value="year_3">III Year</option>
                        </select>
                    </div>
                    
                    
                  
                </div>
                
                <div class="personal_row_1">
                    <div class="frm-template">

                        <label for="">Tc No<span class="mandatory">*</span>
                        </label>
                        <input type="Text" id="tcno" name="tcno" placeholder="Enter Tc No.." />
                    </div>
        
                    <div class="frm-template">
                        <label for="tcappdate">TC Application Date
                        </label>
                        <input type="date" id="tcappdate" name="tcappdate" placeholder="TC Application Date.." />
                    </div>
                    <div class="frm-template">
                </div>
             


                </div>
                <a href="#Applicant_other">
                    <input type="button" class="btn" style="position: relative;right:-80% !important;" value="Next"></a>


   
        </div>

    </section>

    <section id="Applicant_other">
        <div class="Academic_Details">
            <h2>Parent/Guardian Details</h2>
       
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="fname">Father Name<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="fname" id="fname" placeholder="Enter FatherName" required />
                    </div>
                    <div class="frm-template">
                        <label for="mname">Mother Name<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="mname" name="mname" placeholder="Enter MotherName" required/>
                    </div>
                    <div class="frm-template">

                        <label for="gname">Guardian Name
                        </label>
                        <input type="text" name="gname" id="gname" placeholder="Enter GuardianName" />
                    </div>
                    
                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="con-no">Father/Guardian Occupation<span class="mandatory">*</span>
                        </label>
                        <select name="foccupation" id="con-no">
                            <option value="">select</option>
                            <option value="dailywages">DailyWages</option>
                            <option value="govt">Goverment</option>
                            <option value="private">Private</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="con-no1">Mother Occupation
                        </label>
                        <select name="moccupation" id="con-no1">
                            <option value="">select</option>
                            <option value="dailywages">None</option>
                            <option value="dailywages">Dailywages</option>
                            <option value="govt">Goverment</option>
                            <option value="govt">Private</option>
                        </select>
                    </div>

                    <div class="frm-template">
                        <label for="ann-income">Annual Income<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="ann-income" name="ann_income" placeholder="Annual Income" required />
                    </div>
                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="con-no">Contact Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="con-no" name="parent_contact" placeholder="Enter PhoneNumber" required />
                    </div>
                    <div class="frm-template">
                        <label for="saddress">Street<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="saddress" name="address" placeholder="Enter Address" required/>
                    </div>
                    <div class="frm-template">
                        <label for="city">Rural/City<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="city" name="city" placeholder="Enter CityName" required />
                    </div>

                    
                </div>

                <div class="personal_row_1">
                    <div class="frm-template">

                        <label for="district">District<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="district" name="district" placeholder="Enter DistrictName" required />
                    </div>
                    <div class="frm-template">

                        <label for="state">State<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="state" name="state" placeholder="Enter StateName" required/>
                    </div>
                    
                    <div class="frm-template">
                        <label for="pin-code">Pincode<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="pin-code" name="pin_code" placeholder="Enter Pincode" required/>
                    </div>
                    
                   

                </div>
                <div class="personal_row_1" style="justify-content: flex-start;">

                   
                </div>
                <div class="btn-control">

                    <!--input type="button" style="background-color: rgb(31, 224, 10);" class="btn save" value="save"-->
                    <!--input type="clear" style="background-color: #ce5353;" id="clr" class="btn-clr" value="clear"-->
                    <input type="submit" name="edit" class="btn submit" value="submit">

                </div>

        </div>
    
    </section>
	</form>


</body>
</html>