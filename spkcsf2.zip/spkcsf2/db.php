<?php
$conn=mysqli_connect('localhost','root','','spkc');
if(!$conn){
die(mysqli_error("Error"+$conn));
}
?>