<?php
$conn = mysqli_connect('localhost', 'root', '', 'spkc');
if ($_SERVER['REQUEST_METHOD'] == "POST")
 {
    $sname = $_POST['sname'];
    $s_dob = $_POST['s_dob'];
    $gender = $_POST['gender'];
    $phno = $_POST['phno'];
    $wtsapp = $_POST['wtsapp'];
    $email = $_POST['email'];
    $schltype = $_POST['schltype'];
    $schlstu = $_POST['schlstu'];
    $emis = $_POST['emis'];
    $religion = $_POST['religion'];
    $community = $_POST['community'];
    $caste = $_POST['caste'];
    $nation = $_POST['nation'];
    $mother_tongue = $_POST['mother_tongue'];
    $aadharno = $_POST['aadharno'];
    $first_graduation = $_POST['first_graduation'];

    $rollno = $_POST['rollno'];
    $regno = $_POST['regno'];
    $a_year = $_POST['a_year'];
    $a_no = $_POST['a_no'];
    $admdate = $_POST['admdate'];
    $admyear = $_POST['admyear'];
    $year = $_POST['year'];
    $c_type = $_POST['c_type'];
    $c_name = $_POST['c_name'];
    $tcno = $_POST['tcno'];
    $tcappdate = $_POST['tcappdate'];

	$relation=$_POST['relation'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $gname = $_POST['gname'];
    $foccupation = $_POST['foccupation'];
    $moccupation = $_POST['moccupation'];
    $goccupation=$_POST['goccupation'];
    $gann_income=$_POST['gann_income'];
    $ann_income = $_POST['ann_income'];
    $parent_contact = $_POST['parent_contact'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $district = $_POST['district'];
    $state = $_POST['state'];
    $pin_code = $_POST['pin_code'];
   
    $query1 = "insert into personal(rollno,sname,s_dob,gender,phno,wtsapp,email,schltype,schlstu,emis,religion,community,caste,nation,mother_tongue,aadharno,first_graduation)values('$rollno','$sname','$s_dob','$gender','$phno','$wtsapp','$email','$schltype','$schlstu','$emis','$religion','$community','$caste','$nation','$mother_tongue','$aadharno','$first_graduation')";
    $query2 = "insert into academic_details(rollno,regno,academic_year,adm_num,adm_date,adm_year,year,course_type,course_name,tc_no,tc_application_date)values('$rollno','$regno','$a_year','$a_no','$admdate','$admyear','$year','$c_type','$c_name','$tcno','$tcappdate')";
    $query3 = "insert into parent_details(rollno,relation,fname,mname,gname,f_occupation,m_occupation,goccupation,gann_income,ann_income,parent_contact,address,city,district,state,pin_code)values('$rollno','$relation','$fname','$mname','$gname','$foccupation','$moccupation','$goccupation','$gann_income','$ann_income','$parent_contact','$address','$city','$district','$state','$pin_code')";
    $result1 = mysqli_query($conn, $query1);
    $result2 = mysqli_query($conn, $query2);
    $result3 = mysqli_query($conn, $query3);

    if ($result1 && $result2 && $result3)
     {
        echo "<script>alert('success');</script>";
    } 
    else {
        echo "<script>alert('Please enter valid information');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <!--  -----------------------------------SCRIPT---------------------------------------->
    <script src=script.js> </script>
    <!--------------------------------------------------------------------------------------->
    <title>Admin</title>
</head>

<body>
    <div class="header">
        <div class="logo">
            <img src="spkclogo.png" alt="" height="100px" width="100px" style="border-radius: 0px;">
            <div class="clg-name" style="margin-left:10px;">
                <h1 style="color:#ffffff"><span style="font-size:38px;">S</span>ri <span style="font-size:38px;">P</span>aramkalyani <span style="font-size:38px;">C</span>ollege</h1>
                <h2 style="color:rgb(255, 255, 255); font-size:20px; text-align:center;">Alwarkurichi, Tenkasi District
                </h2>
            </div>
        </div>
        <div class="menus">
            <ul>
                <a href="update.php">
                    <li>Update </li>
                </a>
                <a href="">
                    <li>Delete </li>
                </a>
                <a href="getdeatils.php">
                    <li>Retrieve </li>
                </a>
                <a href="sampleretrieve.php">
                    <li>update </li>
                </a>
            </ul>
        </div>

    </div>
    </div>
    <form action="" method="POST">
    <section id="Applicant_Personal">
        <h1 style="margin-left: 15px;">Student Details</h1>
            <div class="personal">
                <h2>Personal Details</h2>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="sname">Student Name<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="sname" name="sname" placeholder="Enter StudentName"  />
                    </div>
                    <div class="frm-template">
                        <label for="s_dof">Date of Birth<span class="mandatory">*</span>
                        </label>
                        <input type="date" name="s_dob" id="s_dof" placeholder="Enter Date of Birth"  />
                    </div>
                    <div class="frm-template">
                        <label for="Gender">Gender<span class="mandatory">*</span>
                        </label>
                        <select name="gender" id="Gender" >
                            <option value="">Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>

                    </div>

                </div>

                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="phone">Phone Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="phone" maxlength="10" name="phno" placeholder="Enter PhoneNumber"  />
                    </div>

                    <div class="frm-template">

                        <label for="wtsapp">Whatsapp Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="wtsapp" maxlength="10" minlength="10" name="wtsapp" placeholder="Enter WhatsappNumber"  />
                    </div>
                    <div class="frm-template">
                        <label for="state">Mail Id<span class="mandatory">*</span>
                        </label>
                        <input type="email" id="mailid" name="email" placeholder="Enter Mail-Id"  />
                    </div>

                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="schltype">School Type<span class="mandatory">*</span>
                        </label>
                        <select name="schltype" id="schltype">
                            <option value="none" selected>Select</option>
                            <option value="Govt">Goverment</option>
                            <option value="Govt.Aided">Govt.Aided</option>
                            <option value="Private">Private</option>
                            <option value="CBSE">CBSE</option>
                        </select>
                    </div>

                    <div class="frm-template">
                        <label for="sclname">School Name<span class="mandatory">*</span>
                        </label>
                        <input type="text" id="sclname" name="schlstu" placeholder="School Name"  />
                    </div>
                    <div class="frm-template">
                        <label for="emis">Emis Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="emis" id="emis" placeholder="Enter EmisNumber"  />
                    </div>
                </div>


                <div class="personal_row_1">


                    <div class="frm-template">
                        <label for="nation">Religion<span class="mandatory">*</span>
                        </label>
                        <select name="religion">
                            <option value="" selected>Select</option>
                            <option value="hindu">Hindu</option>
                            <option value="chirstian">Chirstian</option>
                            <option value="muslim">Muslim</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="nation">Community<span class="mandatory">*</span>
                        </label>
                        <select name="community" id="community" onchange="CasteRender();">
                            <option value="" selected>Select</option>
                        </select>
                    </div>
                    <div class="frm-template">

                        <label for="nation">Caste<span class="mandatory">*</span>
                        </label>
                        <select name="caste" id="comm_caste">
                            <option value="" selected>Select</option>
                            <option value="bcom">caste-1</option>
                            <option value="bca">caste-2</option>
                        </select>
                    </div>
                </div>
                <div class="personal_row_1">

                    <div class="frm-template">
                        <label for="nation">Nationality
                        </label>
                        <select name="nation">
                            <option value="" selected>Select</option>
                            <option value="indian">Indian</option>
                            <option value="others">Others</option>
                        </select>
                    </div>

                    <div class="frm-template">

                        <label for="nation">Mother Tongue
                        </label>
                        <select name="mother_tongue">
                            <option value="" selected>Select</option>
                            <option value="tamil">Tamil</option>
                            <option value="malayalam">Malayalam</option>
                            <option value="telugu">Telugu</option>
                            <option value="kannada">Kannda</option>
                            <option value="hindi">Hindi</option>
                            <option value="others">Others</option>
                        </select>
                    </div>
                    <div class="frm-template">
                        <label for="aadharno">Aadhar Number<span class="mandatory">*</span>
                        </label>
                        <input type="text" name="aadharno" maxlength="12" id="aadharno" placeholder="Enter AadharNumber"  />
                    </div>
                </div>
                <div class="personal_row_1">
                    <div class="frm-template">
                        <label for="first_graduation">First Graduation<span class="mandatory">*</span>
                        </label>
                        <select name="first_graduation" >
                            <option value="" selected>Select</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                    </div>
                </div>
                <div></div>
                <div></div>
                <a href="#Applicant_Academic"><input type="button" class="btn " value="Next" style="position: relative;right:-80% !important;"></a>


            </div>
    </section>

    <section id="Applicant_Academic">
        <div class="Academic_Details">
            <h2>Academic Details</h2>


            <div class="personal_row_1">
                <div class="frm-template">
                    <label for="rollno">Roll Number<span class="mandatory">*</span>
                    </label>
                    <input type="text" id="rollno" name="rollno" placeholder="Enter RollNumber"  />
                </div>
                <div class="frm-template">
                    <label for="regno">Register Number<span class="mandatory">*</span>
                    </label>
                    <input type="text" name="regno" id="regno" placeholder="Enter RegisterNumber"  />
                </div>

                <div class="frm-template">
                    <label for="a_year">Academic Year<span class="mandatory">*</span>
                    </label>
                    <input type="text" id="a_year" name="a_year" placeholder="Enter Academic Year(Ex:2021-2022)"  />

                </div>
            </div>
            <div class="personal_row_1">

                <div class="frm-template">
                    <label for="admno">Admission Number<span class="mandatory">*</span>
                    </label>
                    <input type="text" id="admno" name="a_no" placeholder="Enter AdmissionNumber"  />
                </div>
                <div class="frm-template">
                    <label for="admdate">Admission Date
                    </label>
                    <input type="date" name="admdate" id="admdate" placeholder="Enter AdmissionDate" />
                </div>
                <div class="frm-template">
                    <label for="admdate">Admission Year<span class="mandatory">*</span>
                    </label>
                    <input type="date" name="admyear" id="admyear" placeholder="Enter AdmissionYear..." />
                </div>

            </div>
            <div class="personal_row_1">
                <div class="frm-template">
                    <label for="C_type">CourseType<span class="mandatory">*</span>
                    </label>
                    <select name="c_type" id="C_type" onchange="course_show()">
                        <option value="" selected>Select</option>
                        <option value="ug">UG</option>
                        <option value="pg">PG</option>
                    </select>
                </div>
                <div class="frm-template">
                    <label for="c_name">Course Name<span class="mandatory">*</span>
                    </label>
                    <select name="c_name" id="c_name">
                        <option value="" selected>Select</option>

                    </select>
                </div>
                <div class="frm-template">
                    <label for="clsyear">Year<span class="mandatory">*</span>
                    </label>
                    <select name="year" id="clsyear">
                        <option value="" selected>Select</option>
                        <option value="year_1">I Year</option>
                        <option value="year_2">II Year</option>
                        <option value="year_3">III Year</option>
                    </select>
                </div>



            </div>

            <div class="personal_row_1">
                <div class="frm-template">

                    <label for="">Tc No<span class="mandatory">*</span>
                    </label>
                    <input type="Text" id="tcno" name="tcno" placeholder="Enter Tc No" />
                </div>

                <div class="frm-template">
                    <label for="tcappdate">TC Application Date
                    </label>
                    <input type="date" id="tcappdate" name="tcappdate" placeholder="TC Application Date" />
                </div>
                <div class="frm-template">
                </div>



            </div>
            <a href="#Applicant_other">
                <input type="button" class="btn" style="position: relative;right:-80% !important;" value="Next"></a>



        </div>

    </section>

    <section id="Applicant_other">

<div class="Academic_Details">
    <h2>Parent/Guardian Details</h2>

    <div class="personal_row_1">

        <div class="frm-template">
            <label for="relation">Select Relation:</label>
            <select id="relation" name="relation" onchange="showInfo()">
                <option value="father">Parent</option>
                <option value="guardian">Guardian</option>
            </select>
        </div>
        <div class="personal_row_1" id="fatherInfo" >
        <div class="frm-template" style="margin-left:3vw;">
            <label for="fname">Father Name<span class="mandatory">*</span>
            </label>
            <input type="text" name="fname" id="fname" placeholder="Enter FatherName"  />
        </div>

        <div class="frm-template">
            <label for="con-no">Father Occupation<span class="mandatory">*</span>
            </label>
            <select name="foccupation" id="con-no">
                <option value="">select</option>
                <option value="dailywages">DailyWages</option>
                <option value="govt">Goverment</option>
                <option value="govt">Private</option>
            </select>

        </div>
    </div>
    </div>
    <div class="personal_row_1" id="guardianInfo" style="display:none">
        <div class="frm-template">
            <label for="gname">Guardian Name<span class="mandatory">*</span>
            </label>
            <input type="text" name="gname" id="gname" placeholder="Enter Guardian name"  />
        </div>
        <div class="frm-template">
            <label for="con-no">Guardian Occupation<span class="mandatory">*</span>
            </label>
            <select name="goccupation" id="con-no">
                <option value="">select</option>
                <option value="dailywages">DailyWages</option>
                <option value="govt">Goverment</option>
                <option value="govt">Private</option>
            </select>
        </div>
        <div class="frm-template">
            <label for="ann-income">Annual Income<span class="mandatory">*</span>
            </label>
            <input type="text" id="ann-income" name="gann_income"  placeholder="Annual Income"  />
        </div>
    </div>
    <div class="personal_row_1" id="Hidden_SelectGuad">
        <div class="frm-template">
            <label for="mname">Mother Name<span class="mandatory">*</span>
            </label>
            <input type="text" id="mname" name="mname" placeholder="Enter MotherName"  />
        </div>

        <div class="frm-template">
            <label for="con-no1">Mother Occupation
            </label>
            <select name="moccupation" id="con-no1">
                <option value="">select</option>
                <option value="dailywages">None</option>
                <option value="dailywages">Dailywages</option>
                <option value="govt">Goverment</option>
                <option value="govt">Private</option>
            </select>
        </div>

        <div class="frm-template">
            <label for="ann-income">Annual Income<span class="mandatory">*</span>
            </label>
            <input type="text" id="ann-income" name="ann_income" placeholder="Annual Income"  />
        </div>
    </div>

    <div class="personal_row_1">

        <div class="frm-template">
            <label for="con-no">Contact Number<span class="mandatory">*</span>
            </label>
            <input type="text" id="con-no" name="parent_contact" placeholder="Enter PhoneNumber"  />
        </div>
        <div class="frm-template">
            <label for="saddress">Street<span class="mandatory">*</span>
            </label>
            <input type="text" id="saddress" name="address" placeholder="Enter Address"  />
        </div>
        <div class="frm-template">
            <label for="city">Rural/City<span class="mandatory">*</span>
            </label>
            <input type="text" id="city" name="city" placeholder="Enter CityName"  />
        </div>


    </div>

    <div class="personal_row_1">
        <div class="frm-template">

            <label for="district">District<span class="mandatory">*</span>
            </label>
            <input type="text" id="district" name="district" placeholder="Enter DistrictName"  />
        </div>
        <div class="frm-template">

            <label for="state">State<span class="mandatory">*</span>
            </label>
            <input type="text" id="state" name="state" placeholder="Enter StateName"  />
        </div>

        <div class="frm-template">
            <label for="pin-code">Pincode<span class="mandatory">*</span>
            </label>
            <input type="text" id="pin-code" name="pin_code" placeholder="Enter Pincode"  />
        </div>



    </div>
    <div class="personal_row_1" style="justify-content: flex-start;">


    </div>
    <div class="btn-control">

        <!--input type="button" style="background-color: rgb(31, 224, 10);" class="btn save" value="save"-->
        <!--button type="clear" style="background-color: #ce5353;" id="clr" class="btn clr" value="clear"-->
        <input type="submit" class="btn submit" value="submit">

    </div>

</div>

</section>
    </form>


</body>

</html>