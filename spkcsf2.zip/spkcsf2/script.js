//Name Validations Dynamically

//load Community

window.onload=function(){
    community_list=['OC','BC','DNC','MBC','SC','ST','BCM','SCA'].sort();
    

    var community=document.getElementById('community');

    if(community_list.length>=1){

        for(i=0;i<=community_list.length-1;i++){
            var communityoption=document.createElement("option");
            communityoption.text=community_list[i];
            communityoption.value=community_list[i];
            community.appendChild(communityoption);  
        }
    }

}
//Community Rendering

/*
else if(community==='BC'){
        caste.innerHTML="";
        var casteoption=document.createElement("option");
        casteoption.text="Select";
        casteoption.value="";
        caste.appendChild(casteoption);
        for(i=0;i<=comm_bc.length-1;i++){
            var casteoption=document.createElement("option");
            casteoption.text=comm_bc[i];
            casteoption.value=comm_bc[i];
            caste.appendChild(casteoption);  
        }
    }
*/
function CasteRender(){
bc_caste_lists=['Vaniya Chettiyar','Yadhavar','Senaithalaivar','Illathu Pillaimar','Nadar','Vellaar','Kamaalar','kaikdar','Senguthar','Vaniyar','Vadugar',
'Vellan Chettiyar','Senaiyar','Thulla Vellalar','Soliya Vellalar'].sort();
dnc_caste_lists=['Maravar','Thevar'].sort();
mbc_caste_lists=['Vannar','Vannan','Maruthuvar','Kurumba Gounder','Yogeshwarar','Lebbai','oddar','Padaiyachi'].sort();
sc_caste_lists=['Pallar','Pallan','Vannan','Parayan','Parayar','Adidravidar','Sakkiliyar','Deventhira kula Vellalar'].sort();
st_caste_lists=['Kattunayagan','Malai Kuravar'].sort();
bcm_caste_lists=['Lebbai'].sort();
oc_caste_lists=['Saiva Vellalar','Vellalar','Saiva Pillaimar','Karkathar','Bharamin'].sort();
sca_caste_lists=['Arunthathiyar'].sort();
    
    var community=document.getElementById('community').value;
    var caste=document.getElementById('comm_caste');
    
    if (community==='OC'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=oc_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=oc_caste_lists[i];
            casteoption.value=oc_caste_lists[i];
            caste.appendChild(casteoption);  
        }
        
    }
    else if(community==='BC'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=bc_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=bc_caste_lists[i];
            casteoption.value=bc_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
    else if(community==='DNC'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=dnc_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=dnc_caste_lists[i];
            casteoption.value=dnc_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
    else if(community==='MBC'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=mbc_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=mbc_caste_lists[i];
            casteoption.value=mbc_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
    else if(community==='SC'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=sc_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=sc_caste_lists[i];
            casteoption.value=sc_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
    else if(community==='ST'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=st_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=st_caste_lists[i];
            casteoption.value=st_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
    else if(community==='BCM'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=bcm_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=bcm_caste_lists[i];
            casteoption.value=bcm_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
    else if(community==='SCA'){
        caste.innerHTML="";
        let casteoption=document.createElement("option");
        casteoption.text="select";
        casteoption.value="";
        caste.appendChild(casteoption);
        
        for(i=0;i<=sca_caste_lists.length-1;i++){
            let casteoption=document.createElement("option");
            casteoption.text=sca_caste_lists[i];
            casteoption.value=sca_caste_lists[i];
            caste.appendChild(casteoption);  
        }
    }
}
//Course Validations
function course_show(){
    ug_courses=['B.A.-English','B.Com','B.Com(CS)','BCA I-Batch','BCA II-Batch','B.Sc.Maths','B.Sc.Bio Tech','B.Sc.E&C','B.Sc.Computer Science'];
    pg_courses=['M.Com','M.Sc.Maths','M.Sc.Computer Science'];
    ug_year=['I Year','II Year','III Year'];
    pg_year=['I Year','II Year'];
    var clsyear=document.getElementById('clsyear');
    var ctype=document.getElementById('C_type').value;
    var addcourse=document.getElementById('c_name');
    if (ctype==='ug'){
        clsyear.innerHTML="";
        addcourse.innerHTML="";
        var courseoption=document.createElement("option");
             courseoption.text="Select";
             addcourse.appendChild(courseoption);
        for(i=0;i<=ug_courses.length-1;i++){
            var courseoption=document.createElement("option");
             courseoption.value=ug_courses[i];
             courseoption.text=ug_courses[i];
             addcourse.appendChild(courseoption);
        }
        for (i=0;i<=ug_year.length-1;i++){ 
            var ug_y=document.createElement("option");
            ug_y.value=ug_year[i];
            ug_y.text=ug_year[i];
            clsyear.appendChild(ug_y);

        }
    }
    else if(ctype==='pg'){
        clsyear.innerHTML="";
            addcourse.innerHTML="";
              var courseoption=document.createElement("option");
             courseoption.text="Select";
            for(i=0;i<=pg_courses.length-1;i++){
                var courseoption=document.createElement("option");
                 courseoption.value=pg_courses[i];
                 courseoption.text=pg_courses[i];
                 addcourse.appendChild(courseoption);
            }
            for (i=0;i<=pg_year.length-1;i++){
                
                var pg_y=document.createElement("option");
                pg_y.value=ug_year[i];
                pg_y.text=ug_year[i];
                clsyear.appendChild(pg_y);
    
            }
        }
        else{
            addcourse.innerHTML="";
            clsyear.innerHTML="";
        }  
}
function showInfo() {
    var relation = document.getElementById('relation').value;
    var fatherInfo = document.getElementById('fatherInfo');
    var guardianInfo = document.getElementById('guardianInfo');
   var mom_details = document.getElementById('Hidden_SelectGuad');

    //Hide both sections initially
    fatherInfo.style.display = 'none';
    guardianInfo.style.display = 'none';

    // Show the relevant section based on the selected relation
    if (relation === 'parent') {
        guardianInfo.style.display = 'none';
        fatherInfo.style.display = 'flex';
        mom_details.style.display = 'flex';
   

    } else if (relation === 'guardian') {
        fatherInfo.style.display = 'none';
        guardianInfo.style.display = 'flex';
        mom_details.style.display = 'none';
     
    }
    else{
        fatherInfo.style.display = 'none';
        guardianInfo.style.display = 'none';

    }
}



