<?php
include 'db.php';
?>
<html>
<head>
<title>
</title>
<link rel="stylesheet" href="update.css">
</head>
<body>
<div class="header">

<div class="logo">
	<img src="spkclogo.png" alt="" height="100px" width="100px" style="border-radius: 0px;">
	<div class="clg-name" style="margin-left:10px;">
		<h1 style="color:#ffffff"><span style="font-size:38px;">S</span>ri <span style="font-size:38px;">P</span>aramkalyani <span style="font-size:38px;">C</span>ollege</h1>
		<h2 style="color:rgb(255, 255, 255); font-size:20px; text-align:center;">Alwarkurichi, Tenkasi District
		</h2>
	</div>
</div>
<div class="menus">
	<ul>
	<a href="index.php">
			<li>Home </li>
		</a>
		<a href="update.php">
			<li>Update </li>
		</a>
		
		<a href="sampleretrieve.php">
			<li>Retrieve </li>
		</a>
		<a href="sampleretrieve.php">
			<li>update </li>
		</a>
	</ul>
</div>

</div>
<form method="POST">
<div class="update">
<div id="update-field">
<input type="text" placeholder="search" name="search">
<button name="submit">search</button>
<div id="update-field">
</div>
</form>
<button class="btn">
	<a href="download.php?filename=personal">Download in XL Format</a>
	</button>
	<section>
					<table class="table table-order">
						<tr>
						<th>rollno number</th>
						<th>Student Name</th>
						<th>Email</th>
						<th>Phoneno</th>
						<th>Class</th>
						</tr>
		<?php
		if(isset($_POST['submit']))
{
	$search=$_POST['search'];
	$sql = "select * from personal join academic_details on personal.rollno=academic_details.rollno join parent_details on personal.rollno=parent_details.rollno where personal.rollno='$search'";

	$result=mysqli_query($conn,$sql);

		while($row=mysqli_fetch_assoc($result))
		{
			echo'
			<tr>
			<td>'.$row{'rollno'}.'</td>
			<td>'.$row{'sname'}.'</td>
			<td>'.$row{'email'}.'</td>
			<td>'.$row{'phno'}.'</td>
			<td>'.$row{'course_name'}.'</td>
			
			</tr>';
		}
}
		?>
		</table>
		</section>
		
</body>
</html>
	