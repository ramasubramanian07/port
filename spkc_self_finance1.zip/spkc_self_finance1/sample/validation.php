<?php
// PERSONAL DETAILS----------------------------------------------------
// To store validation error messages
$snameError = $s_dobError = $genderError = $phnoError = $wtsappError = $emailError = $schltypeError = $schlstuError = $emisError = $religionError = $communityError = $casteError = $nationError= $mother_tongueError = $aadharnoError = $first_gradutaionError=" ";
$rollnoError = $regnoError = $a_yearError = $a_noError = $admdateError = $admyearError = $yearError = $c_typeError = $c_nameError = $tcnoError = $tcappdateError ="";
$relationError = $fnameError = $mnameError = $gnameError = $foccupationError = $moccupationError = $ann_incomeError = $parent_contactError = $addressError = $cityError = $districtError = $stateError = $pin_codeError ="";


//  User inputs
$sname = $s_dob = $gender = $phno = $wtsapp = $email = $schltype = $schlstu = $emis = $religion = $community = $caste = $nation= $mother_tongue = $aadharno = $first_gradutaion=" ";
$rollno = $regno = $a_year = $a_no = $admdate = $admyear = $year = $c_type = $c_name = $tcno = $tcappdate ="";
$relation = $fname = $mname = $gname = $foccupation = $moccupation = $ann_income = $parent_contact = $address = $city = $district = $state = $pin_code ="";

// Check if the form is submitted

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate student name

    if (empty($_POST["sname"])) {
        $snameError = "Student name is required";
    } else {
        $sname = test_input($_POST["sname"]);
        // Check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $sname)) {
            $snameError = "  Student name only letters and white space allowed";
        }
    }

    // Validate date of birth
    if (empty($_POST["s_dob"])) {
        $s_dobError = "Date of birth is required";
    } else {
        $s_dob = test_input($_POST["s_dob"]);
        // Check if date of birth is valid (you can customize this based on your needs)
        if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $s_dob)) {
            $s_dobError = "Invalid date of birth format";
        }
    }

    // Validate gender

    if(empty($_POST["gender"])) {
        $genderError = "Gender is required";
    }

    // Validate phone number

    if (empty($_POST["phno"])) {
        $phnoError = "Phone number is required";
    } else {
        $phno = test_input($_POST["phno"]);
        // Check if phone number is valid (you can customize this based on your needs)
        if (!preg_match("/^[0-9]{10}$/", $phno)) {
            $phnoError = "Invalid phone number format";
        }
    }

    // Validate whatsapp number

    if (empty($_POST["wtsapp"])) {
        $$wtsappError = "Whatsapp number is required";
    } else {
        $wtsapp = test_input($_POST["wtsapp"]);
        // Check if phone number is valid (you can customize this based on your needs)
        if (!preg_match("/^[0-9]{10}$/",$wtsapp)) {
            $$wtsappError = "Invalid whatsapp number format";
        }
    }



    // Validate email

    if (empty($_POST["email"])) {
        $emailError = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        // Check if email is valid
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailError = "Invalid email format";
        }
    }

    // Validate school type

    if(empty($_POST["schltype"])) {
        $schltypeError = "School Type is required";
    }


    //Validate school name

    if(empty($_POST["schlstu"])) {
        $schlstuError="School name is required";
    }else {
        $schlstu = test_input($_POST["schlstu"]);
        // Check if name only contains letters and whitespace
        if (!preg_match("/^[a-zA-Z ]*$/", $schlstu)) {
            $schlstuError = " school name only letters and white space allowed";
        }
    }

    // Validate Emis number

    if(empty($_POST["emis"])) {
        $emisError="Emis number is required";
    } else {
        $emis= test_input($_POST["emis"]);
        // Check if phone number is valid (you can customize this based on your needs)
        if (!preg_match("/^[0-9]$/", $emis)) {
            $emisError = "Invalid emis number format";
        }
    }

    // Validate religion

    if(empty($_POST["religion"])) {
        $religionError= "Religion is required";
    }


    // Validate community

    if(empty($_POST["community"])) {
        $communityError = "Community is required";
    }


    // Validate caste

    if(empty($_POST["caste"])) {
        $casteError = "Caste is required";
    }

    // Validate nationality

    if(empty($_POST["nation"])){
        $nationError="Nationality is required";
    }
    
    
    // Validate mother tonque

    if(empty($_POST["mother_tongue"])){
        $mother_tonqueError="Mother tonque is required";
    }

    //================================= Section 2 ========================================//

    // Validate Roll number

    if (empty($_POST["rollno"])) {
        $rollnoError = "Roll number is required";
    } else {
        $rollno = test_input($_POST["rollno"]);
        // Check if phone number is valid (you can customize this based on your needs)
        if (!preg_match("/^[0-9]$/", $rollno)) {
            $rollnoError = "Invalid roll number format";
        }
    }

    // Validate Register number

    if (empty($_POST["regno"])) {
        $regnoError = "Register number is required";
    } else {
        $regno = test_input($_POST["regno"]);
        // Check if phone number is valid (you can customize this based on your needs)
        if (!preg_match("/^[0-9]$/", $regno)) {
            $regnoError = "Invalid register number format";
        }
    }

    // Validate Academic year 

    if(empty($_POST["a_year"])){
        $a_yearError = "Academic year is required";
    } else{
        $a_year=test_input($_POST["a_year"]);
        // checking the format
        if(!preg_match("/^\d{4}-\d{4}$/",$a_year)){
            $a_yearError = "Invalid academic year format";

        }
    }

    // Validate Admission number

    if(empty($_POST["a_no"])){
        $a_noError = "Admission number is required";
    }else{
        $a_no = test_input($_POST["a_no"]);
        // checking the format
        if(!preg_match("/^[0-9]$/",$a_no)){
            $a_noError = "Invalid admission number format";
        } 
    
    }

    // Validate Admission date

    if(empty($_POST["admdate"])){
        $admdateError = "Admission date is required";
    }


    // Validate Admission year

    if(empty($_POST["admyear"])){
        $admyearError = "Admission year is required";
    }else{
        $admyear=test_input($_POST["admyear"]);
        //Checking the format
        if(!preg_match("/^[0-9]{4}$/",$admyear)){
            $admyearError = "Invalid Admission year format";
        }
    }

    // Validate Year

    if(empty($_POST["year"])){
        $yearError = "Year is required";
    }

    // Validate Course type

    if(empty($_POST["c_type"])){
        $c_typeError = "Course type is required";
    }

     // Validate Course name

     if(empty($_POST["c_name"])){
        $c_nameError = "Course name is required";
    }


    // Validate TC number

    if(empty($_POST["tcno"])){
        $tcnoError = "TC number is required";
    }else{
        $tcno=test_input($_POST["tcno"]);
        if(!preg_match("/^[0-9]$/",$tcno)){
            $tcnoError="Invalid TC number format";
        }
    }

    // Validate TC application date

    if(empty($_POST["tcappdate"])){
        $tcappdateError="TC application date is required";
    
    }

    /* =================================== Section 3 ==============================================*/

    // Validate Relation

    if(empty($_POST[" relation"])){
        $relationError="Relation is required";
    }

    //Validate father name

    $fname=test_input($_POST["fname"]);
    if(!preg_match("/^[a-zA-Z ]*$/")){
        $fnameError = "Invalid father name format";
    }


     //Validate mother name

     $mname=test_input($_POST["mname"]);
     if(!preg_match("/^[a-zA-Z ]*$/")){
         $mnameError = "Invalid mother name format";
     }

      //Validate guardian name

    $gname=test_input($_POST["gname"]);
    if(!preg_match("/^[a-zA-Z ]*$/")){
        $gnameError = "Invalid guardian name format";
    }

    // Validating Father occupation 

    if(empty($_POST["foccupation"])){
        $foccupationError="Father Occupation is required";
    }

     // Validating mother occupation 

     if(empty($_POST["moccupation"])){
        $moccupationError="Mother Occupation is required";
    }


     // Validating guardian occupation 

     if(empty($_POST["goccupation"])){
        $goccupationError="Guardian Occupation is required";
    }


    // Validate Annual income

    if(empty($_POST["ann_income"])){
        $ann_income="Annual income is required";
    }
        else{
            $ann_income=test_input($_POST["ann_income"]);
            if(!preg_match("/^[0-9]$/",$ann_income)){
                $ann_incomeError="Invalid annual income format";
        }
    }

    // Validate Parent contact

    if (empty($_POST["parent_contact"])) {
        $parent_contactError = "Parent contact is required";
    } else {
        $parent_contact = test_input($_POST["parent_contact"]);
        // Check 
        if (!preg_match("/^[0-9]{10}$/", $parent_contact)) {
            $parent_contactError = "Invalid parent contatc format";
        }
    }

    // Validate Address

     if (empty($_POST["address"])) {
        $addressError = "Address is required";
    } else {
        $address = test_input($_POST["address"]);
        // Check 
        if (!preg_match("/^\d+\s[A-z]+\s[A-z]+,\s[A-z]+\s\d+$/",$address)) {
            $addressError = "Invalid address format";
        }
    }

    // Validate city

    if (empty($_POST["city"])) {
        $cityError = "City is required";
    } else {
     $city=test_input($_POST["city"]);
     if(!preg_match("/^[a-zA-Z ]*$/",$city)){
         $city = "Invalid city format";
     }
    }

    // Validate district

    if (empty($_POST["district"])) {
        $districtError = "District is required";
    } else {
     $district=test_input($_POST["district"]);
     if(!preg_match("/^[a-zA-Z ]*$/",$city)){
         $districtError = "Invalid district format";
     }
    }

    // Validate State

    if (empty($_POST["state"])) {
        $stateError = "state is required";
    } else {
     $state=test_input($_POST["state"]);
     if(!preg_match("/^[a-zA-Z ]*$/",$city)){
         $stateError = "Invalid state format";
     }
    }
    

    //Validate Pincode

    // Validate State

    if (empty($_POST["pin_code"])) {
        $pin_codeError = "Pincode is required";
    } else {
     $pin_code=test_input($_POST["pin_code"]);
     if(!preg_match("/^[0-9]{6}$/",$city)){
         $pin_codeError = "Invalid pincode format";
     }
    }











    

    
    // If there are no validation errors, process the form data further

    if (empty($snameError) && empty($s_dobError) &&  empty($genderError) && empty($phnoError) && 
        empty($wtsappError) && empty( $emailError) && empty( $schltypeError) && empty( $schlstuError) &&
        empty( $emisError) && empty( $religionError) && empty($communityError) && empty( $casteError) && 
        empty($nationError) && empty($mother_tongueError)&& empty( $aadharnoError) && empty( $first_gradutaionError))
    {
        // Process the form data, save to database, send email, etc.
        // ...Here the code to store will be attached
        $data = trim($data);
    }


// Helper function to sanitize user input

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>
