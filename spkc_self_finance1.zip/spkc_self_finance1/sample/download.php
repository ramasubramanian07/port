<?php
include 'retrieval.php';
if(isset($_GET['filename']))
{

$filename=$_GET['filename'].".xls";
header("Content-Disposition:attachment;filename=\"$filename\"");
header("Content-Type:application/vnd.ms-excel");
include 'db.php';
//$sql = "select * from personal join academic_details on personal.rollno=academic_details.rollno join parent_details on personal.rollno=parent_details.rollno where academic_details.course_name='$course_name'";
$sql = "
SELECT *
FROM personal
JOIN academic_details ON personal.rollno = academic_details.rollno
JOIN parent_details ON personal.rollno = parent_details.rollno
WHERE academic_details.course_name = '$course_name'";

if (!empty($a_year)) {
	$sql .= " AND academic_details.academic_year='$a_year'";
}
if (!empty($year)) {
	$sql .= " AND academic_details.year='$year'";
}
if (!empty($community)) {
	$sql .= " AND personal.community='$community'";
}
if (!empty($schltype)) {
	$sql .= " AND personal.schltype='$schltype'";
}
if (!empty($first_graduation)) {
	$sql .= " AND personal.first_graduation='$first_graduation'";
}
if (!empty($foccupation)) {
	$sql .= " AND parent_details.f_occupation='$foccupation'";
}
if (!empty($moccupation)) {
	$sql .= " AND parent_details.m_occupation='$moccupation'";
}

//$sql="";
$result = mysqli_query($conn, $sql);

//if(mysqli_num_rows($result)>0)
if($result)
{
	$heading=false;
	while($row=mysqli_fetch_assoc($result)){
	if(!$heading){
		echo implode("\t",array_keys($row))."\r\n";
		$heading=true;
	}
	echo implode("\t",array_values($row))."\r\n";
	}
}
}