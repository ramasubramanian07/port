<?php
include 'db.php';
      
if (isset($_POST['Retrieve'])) 
{
    $course_type = $_POST['course_type'];
    $course_name = $_POST['course_name'];
    $year = $_POST['year'];
    $a_year = $_POST['a_year'];
    $community = $_POST['community'];
    $schltype = $_POST['schltype'];
    $first_graduation = $_POST['first_graduation'];
    $foccupation = $_POST['foccupation'];
    $moccupation = $_POST['moccupation'];
    $sql = "
SELECT *
FROM personal
JOIN academic_details ON personal.rollno = academic_details.rollno
JOIN parent_details ON personal.rollno = parent_details.rollno
WHERE academic_details.course_type = '$course_type'";

    //academic_details.course_type = ?
    if (!empty($course_name)) {
        $sql .= " AND academic_details.course_name='$course_name'";
    }
    if (!empty($year)) {
        $sql .= " AND academic_details.year='$year'";
    }
    if (!empty($a_year)) {
        $sql .= " AND academic_details.academic_year='$a_year'";
    }
    if (!empty($community)) {
        $sql .= " AND personal.community='$community'";
    }
    if (!empty($schltype)) {
        $sql .= " AND personal.schltype='$schltype'";
    }
    if (!empty($first_graduation)) {
        $sql .= " AND personal.first_graduation='$first_graduation'";
    }
    if (!empty($foccupation)) {
        $sql .= " AND parent_details.f_occupation='$foccupation'";
    }
    if (!empty($moccupation)) {
        $sql .= " AND parent_details.m_occupation='$moccupation'";
    }


    $result = mysqli_query($conn, $sql);

    //while ($row = mysqli_fetch_assoc($result)) {
        $csvData = "sep=,\n"; // Excel separator
        $csvData .= implode(",", array_keys($result->fetch_assoc())) . "\n";

        $result->data_seek(0); // Reset the result set pointer
        while ($data = $result->fetch_assoc()) {
            $csvData .= implode(",", $data) . "\n";
        }

        // Output CSV file to the browser
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="retrieval_data.csv"');
        header('Cache-Control: max-age=0');
        echo $csvData;
        $conn->close();
    }   
?>